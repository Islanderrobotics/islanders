# Islanders
this is a python packaged dessigned to make artificial Intelligence engineers, machine learning engineers, and Data 
Sciencist lives easier to do there job. within this package you will have the ability to use irdatacleanings  methods as well as

- datasets: this method is for those part of the islander community where you will be able to run code like,
```python
import islanders as ir
gifts = ir.dataset("amazon electronic")
titanic = ir.dataset("titanic")
```
